# SurveyPro Android App

A professional GNSS/surveying field app for Android, designed for use with the Hi-Target E800 GNSS receiver (and similar Bluetooth SPP NMEA devices).

## Features

- **GNSS Connection**: Bluetooth SPP connect to E800/GNSS receiver, live NMEA stream display, position parsing from GPGGA sentences
- **Survey Manager**: Add/view survey points with name, lat, lon, elevation stored in Room (SQLite) database
- **Stakeout**: Navigate to a saved point with compass direction arrow and distance/bearing readout
- **Map View**: OSMDroid map showing all saved points as markers (works offline with cached tiles)

## Requirements

- Android 7.0+ (API 24+)
- Android Studio Hedgehog or later
- A paired Bluetooth GNSS device (Hi-Target E800 or similar SPP-capable receiver)

## Setup

1. **Clone / open in Android Studio**
2. **Replace `app/google-services.json`** with your own Firebase project's file (required for Crashlytics). Get it from https://console.firebase.google.com
3. **Add JitPack repository** to `settings.gradle` (needed for osmbonuspack):
   ```groovy
   dependencyResolutionManagement {
       repositories {
           google()
           mavenCentral()
           maven { url 'https://jitpack.io' }
       }
   }
   ```
4. **Build & run** on a physical Android device (Bluetooth requires real hardware)

## Important Notes

- The `StakeoutActivity` uses a placeholder current position (37.7749, -122.4194). Wire it to live GNSS data from `GnssActivity` via a shared ViewModel or broadcast for production use.
- The `MapActivity` loads points using `runBlocking` on a background thread for simplicity. For production, use proper coroutine/lifecycle patterns.
- `WRITE_EXTERNAL_STORAGE` permission is declared for OSMDroid tile caching; on Android 10+ this is not required but harmless.

## Architecture

- **Room** (SQLite) for point persistence
- **ViewModel + LiveData** for lifecycle-safe UI updates
- **Kotlin Coroutines** for Bluetooth I/O
- **OSMDroid** for offline-capable map tiles
- **Firebase Crashlytics** for crash reporting

## License

MIT
