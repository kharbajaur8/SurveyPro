package com.surveypro
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.preference.PreferenceManager
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import com.surveypro.data.SurveyDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
class MapActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this))
        setContentView(R.layout.activity_map)
        mapView = findViewById(R.id.mapView)
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(15.0)
        Thread {
            val db = SurveyDatabase.getInstance(this)
            val dao = db.pointDao()
            val points = runBlocking { dao.getAllPoints().first() }
            runOnUiThread {
                for (p in points) {
                    val marker = Marker(mapView)
                    marker.position = GeoPoint(p.latitude, p.longitude)
                    marker.title = p.name
                    marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    mapView.overlays.add(marker)
                }
                if (points.isNotEmpty()) mapView.controller.setCenter(GeoPoint(points.first().latitude, points.first().longitude))
                mapView.invalidate()
            }
        }.start()
    }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { super.onPause(); mapView.onPause() }
}
