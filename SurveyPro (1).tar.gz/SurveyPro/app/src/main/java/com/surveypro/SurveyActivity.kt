package com.surveypro
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.surveypro.data.PointEntity
import com.surveypro.ui.SurveyViewModel
class SurveyActivity : AppCompatActivity() {
    private lateinit var viewModel: SurveyViewModel
    private lateinit var adapter: PointAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_survey)
        viewModel = ViewModelProvider(this).get(SurveyViewModel::class.java)
        val recyclerView = findViewById<RecyclerView>(R.id.pointsRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = PointAdapter { point ->
            val intent = Intent(this, StakeoutActivity::class.java)
            intent.putExtra("target_lat", point.latitude)
            intent.putExtra("target_lon", point.longitude)
            intent.putExtra("target_name", point.name)
            startActivity(intent)
        }
        recyclerView.adapter = adapter
        viewModel.allPoints.observe(this) { points -> adapter.submitList(points) }
        findViewById<Button>(R.id.btnAddPoint).setOnClickListener { showAddPointDialog() }
        findViewById<Button>(R.id.btnShowMap).setOnClickListener { startActivity(Intent(this, MapActivity::class.java)) }
    }
    private fun showAddPointDialog() {
        val builder = AlertDialog.Builder(this)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_add_point, null)
        val nameInput = dialogView.findViewById<android.widget.EditText>(R.id.pointName)
        val latInput = dialogView.findViewById<android.widget.EditText>(R.id.pointLat)
        val lonInput = dialogView.findViewById<android.widget.EditText>(R.id.pointLon)
        val elevInput = dialogView.findViewById<android.widget.EditText>(R.id.pointElev)
        builder.setTitle("Add Survey Point")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString()
                val lat = latInput.text.toString().toDoubleOrNull() ?: 0.0
                val lon = lonInput.text.toString().toDoubleOrNull() ?: 0.0
                val elev = elevInput.text.toString().toDoubleOrNull() ?: 0.0
                if (name.isNotBlank()) viewModel.insertPoint(name, lat, lon, elev)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
