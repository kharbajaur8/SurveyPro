package com.surveypro
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*
class StakeoutActivity : AppCompatActivity() {
    private lateinit var distanceText: TextView
    private lateinit var bearingText: TextView
    private lateinit var directionArrow: TextView
    private var currentLat = 37.7749
    private var currentLon = -122.4194
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stakeout)
        distanceText = findViewById(R.id.stakeoutDistance)
        bearingText = findViewById(R.id.stakeoutBearing)
        directionArrow = findViewById(R.id.arrow)
        val targetLat = intent.getDoubleExtra("target_lat", 0.0)
        val targetLon = intent.getDoubleExtra("target_lon", 0.0)
        val targetName = intent.getStringExtra("target_name") ?: "Target"
        supportActionBar?.title = "Stakeout: $targetName"
        updateStakeout(targetLat, targetLon)
    }
    private fun updateStakeout(targetLat: Double, targetLon: Double) {
        val dLat = Math.toRadians(targetLat - currentLat)
        val dLon = Math.toRadians(targetLon - currentLon)
        val lat1 = Math.toRadians(currentLat)
        val lat2 = Math.toRadians(targetLat)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val distance = 6371000 * c
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        val bearing = Math.toDegrees(atan2(y, x)).let { (it + 360) % 360 }
        distanceText.text = String.format("Distance: %.1f m", distance)
        bearingText.text = String.format("Bearing: %.0f deg", bearing)
        directionArrow.text = when (bearing) {
            in 0.0..22.5, in 337.5..360.0 -> "N"
            in 22.5..67.5 -> "NE"
            in 67.5..112.5 -> "E"
            in 112.5..157.5 -> "SE"
            in 157.5..202.5 -> "S"
            in 202.5..247.5 -> "SW"
            in 247.5..292.5 -> "W"
            else -> "NW"
        }
    }
}
