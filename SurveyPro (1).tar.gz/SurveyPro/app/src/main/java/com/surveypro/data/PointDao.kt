package com.surveypro.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface PointDao {
    @Insert suspend fun insert(point: PointEntity)
    @Update suspend fun update(point: PointEntity)
    @Delete suspend fun delete(point: PointEntity)
    @Query("SELECT * FROM points ORDER BY name ASC") fun getAllPoints(): Flow<List<PointEntity>>
    @Query("SELECT * FROM points WHERE id = :id") suspend fun getPointById(id: Long): PointEntity?
}
