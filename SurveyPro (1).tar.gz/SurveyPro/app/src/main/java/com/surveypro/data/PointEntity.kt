package com.surveypro.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "points")
data class PointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val elevation: Double,
    val timestamp: Long = System.currentTimeMillis()
)
