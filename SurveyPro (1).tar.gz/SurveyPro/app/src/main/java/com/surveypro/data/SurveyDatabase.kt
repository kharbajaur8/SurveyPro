package com.surveypro.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities = [PointEntity::class], version = 1, exportSchema = false)
abstract class SurveyDatabase : RoomDatabase() {
    abstract fun pointDao(): PointDao
    companion object {
        @Volatile private var INSTANCE: SurveyDatabase? = null
        fun getInstance(context: Context): SurveyDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, SurveyDatabase::class.java, "survey_database").build().also { INSTANCE = it }
            }
        }
    }
}
