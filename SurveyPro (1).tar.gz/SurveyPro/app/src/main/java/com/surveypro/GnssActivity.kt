package com.surveypro
import android.Manifest
import android.bluetooth.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.InputStream
import java.util.*
class GnssActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private lateinit var nmeaView: TextView
    private lateinit var connectBtn: Button
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var isReading = false
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    companion object {
        private const val E800_UUID = "00001101-0000-1000-8000-00805F9B34FB"
        private const val REQUEST_BT_PERMISSIONS = 1
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gnss)
        statusText = findViewById(R.id.gnssStatus)
        nmeaView = findViewById(R.id.nmeaData)
        connectBtn = findViewById(R.id.btnConnectGnss)
        connectBtn.setOnClickListener {
            if (checkPermissions()) connectToGnss()
            else requestPermissions()
        }
    }
    private fun checkPermissions(): Boolean {
        val perms = listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION)
        return perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }
    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_BT_PERMISSIONS)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BT_PERMISSIONS && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) connectToGnss()
        else Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show()
    }
    private fun connectToGnss() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            statusText.text = "Bluetooth not available/enabled"
            return
        }
        val target = adapter.bondedDevices.find { it.name?.contains("E800", true) == true || it.name?.contains("GNSS", true) == true }
        if (target == null) {
            statusText.text = "No E800/GNSS paired"
            return
        }
        statusText.text = "Connecting..."
        mainScope.launch(Dispatchers.IO) {
            try {
                val socket = target.createRfcommSocketToServiceRecord(UUID.fromString(E800_UUID))
                socket.connect()
                bluetoothSocket = socket
                inputStream = socket.inputStream
                withContext(Dispatchers.Main) { statusText.text = "Connected"; connectBtn.isEnabled = false }
                readNmeaStream()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { statusText.text = "Failed: ${e.message}" }
            }
        }
    }
    private suspend fun readNmeaStream() {
        isReading = true
        val reader = inputStream?.bufferedReader() ?: return
        var line: String?
        while (isReading && reader.readLine().also { line = it } != null) {
            line?.let { nmea ->
                parseNmeaSentence(nmea)
                withContext(Dispatchers.Main) {
                    nmeaView.append("$nmea\n")
                    val lines = nmeaView.text.split("\n")
                    if (lines.size > 20) nmeaView.text = lines.takeLast(20).joinToString("\n")
                }
            }
        }
    }
    private fun parseNmeaSentence(sentence: String) {
        if (sentence.startsWith("\$GPGGA")) {
            val parts = sentence.split(",")
            if (parts.size >= 10) {
                val lat = parts[2] + " " + parts[3]
                val lon = parts[4] + " " + parts[5]
                val sats = parts[7]
                val hdop = parts[8]
                runOnUiThread { statusText.text = "Lat: $lat, Lon: $lon | Sats: $sats | HDOP: $hdop" }
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        isReading = false
        bluetoothSocket?.close()
        mainScope.cancel()
    }
}
