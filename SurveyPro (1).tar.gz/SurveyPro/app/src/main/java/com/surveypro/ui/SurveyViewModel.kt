package com.surveypro.ui
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.surveypro.data.PointEntity
import com.surveypro.data.SurveyDatabase
import kotlinx.coroutines.launch
class SurveyViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = SurveyDatabase.getInstance(application).pointDao()
    val allPoints = dao.getAllPoints().asLiveData()
    fun insertPoint(name: String, lat: Double, lon: Double, elev: Double) {
        viewModelScope.launch { dao.insert(PointEntity(name = name, latitude = lat, longitude = lon, elevation = elev)) }
    }
    fun deletePoint(point: PointEntity) { viewModelScope.launch { dao.delete(point) } }
}
