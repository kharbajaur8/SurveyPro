package com.surveypro
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
class LauncherActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)
        findViewById<Button>(R.id.btnGnss).setOnClickListener { startActivity(Intent(this, GnssActivity::class.java)) }
        findViewById<Button>(R.id.btnSurvey).setOnClickListener { startActivity(Intent(this, SurveyActivity::class.java)) }
    }
}
