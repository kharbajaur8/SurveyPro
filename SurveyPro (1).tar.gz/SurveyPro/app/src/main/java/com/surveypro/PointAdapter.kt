package com.surveypro
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.surveypro.data.PointEntity
class PointAdapter(private val onClick: (PointEntity) -> Unit) : ListAdapter<PointEntity, PointAdapter.ViewHolder>(PointDiffCallback()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent, false) as TextView
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val point = getItem(position)
        holder.textView.text = "${point.name}  (${point.latitude}, ${point.longitude})"
        holder.itemView.setOnClickListener { onClick(point) }
    }
    class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)
    class PointDiffCallback : DiffUtil.ItemCallback<PointEntity>() {
        override fun areItemsTheSame(oldItem: PointEntity, newItem: PointEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: PointEntity, newItem: PointEntity) = oldItem == newItem
    }
}
